from matplotlib import pyplot

estados=["COAHUILA","GUERRERO","SONORA","OAXACA","ZACATECAS","TOTALES"]

fallecidos=[1921,1977,2928,1479,832,9137]

colores=["#ADD439","#FFE873","#787CB5","#2E90E8", "#F75F07","#737373"]

pyplot.title("GRAFICA DE COVID-19 EN ESTADOS DE MEXICO")
pyplot.ylabel("MUERTES")
pyplot.xlabel("ESTADOS")
pyplot.bar(estados, height=fallecidos, color=colores, width= 0.5,)
pyplot.show()
